const sendEmail = require("./emailClientApi");


sendEmail({
  to: [],
  content: "", // template from sendinblue api
  contentParams: {}, // key and value for replace in the template
});
