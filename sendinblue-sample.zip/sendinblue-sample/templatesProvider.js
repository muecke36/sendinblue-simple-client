function getTemplate(id = "") {
  return;
}

module.exports = getTemplate;
