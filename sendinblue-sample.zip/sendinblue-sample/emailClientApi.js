var SibApiV3Sdk = require("sib-api-v3-sdk");
var defaultClient = SibApiV3Sdk.ApiClient.instance;

const defaultSenderr = {
  name: "Haila Contact",
  email: "donotreply@haila.com.br",
};

const sendEmail = () =>
  new Promise((resolve, reject) => {
    let apiKey = defaultClient.authentications["api-key"];
    apiKey.apiKey = process.env.API_KEY;

    let apiInstance = new SibApiV3Sdk.TransactionalEmailsApi();
    let sendSmtpEmail = apiInstance.SendSmtpEmail();

    sendSmtpEmail.subject = "My {{params.subject}}";
    sendSmtpEmail.htmlContent =
      "<html><body><h1>This is my first transactional email {{params.parameter}}</h1></body></html>";
    sendSmtpEmail.sender = defaultSenderr;
    sendSmtpEmail.to = [
      { email: "webdevlucas@gmail.com", name: "Lucas Pedroso" },
    ];
    sendSmtpEmail.params = {
      parameter: "My param value",
      subject: "New Subject",
    };

    apiInstance.sendTransacEmail(sendSmtpEmail).then(
      function (data) {
        console.log(
          "API called successfully. Returned data: " + JSON.stringify(data)
        );
      },
      function (error) {
        console.error(error);
      }
    );
  });
